#pragma once
#include<fstream>
#include<string>
#include<iostream>
#include<iomanip>
#include<stdio.h>
#include<algorithm>
#include<sstream>
#include <stdio.h>
#include<conio.h>
#include"LinkedStack.h"
#include"LinkedList.h"
#include"CommandPlus.h"
#include"BinarySearchTree.h"


using namespace std;


class XiEditor {

public:
	void printLines();
	//Prints out all the lines


	XiEditor(string, string);
	// Constructor reads in file, counts number of lines, creates an array and fills it with the contents of the file 
	//Parameters : name of a text file

	void addToUndo(char);

	void removeLine();
	//removes the line that is preceded with the star when pressing X

	void removeChar();
	//Deletes the char pointed to by the carret '^'


	void moveLeft();
	// Moves the '^' one unit to the left

	void moveRight();
	// Moves the '^' one unit to the right


	void moveUp();
	//Moves the '*' one unit up


	void moveDown();
	//Moves the '*' one unit down


	void fixText();
	//Fixes the inconsistencies with moving above the limited number of lines, above the max chars...

	void undo();

	void insertChar();
	//Inserts char at _curPosition on the line you were at

	void insertLine();
	//Inserts a whole new line at _curLine

	void gotoXY(int column, int line);

private:

	int _curLine;
	//Number of the line

	int _curPosition;
	///Position in a certain line

	int _previousPosition;

	int _maxLines;
	// Number of lines in the actual file

	int _size;
	//Max size of the array of strings

	LinkedList<string> _lines;
	//LinkedList of strings that contains all the text of the file

	LinkedStack<CommandPlus> undoStack;
	//Stack used for the undo operation

	std::unique_ptr<BinarySearchTree<std::string>> keywordTreePtr = std::make_unique<BinarySearchTree<std::string>>();

};