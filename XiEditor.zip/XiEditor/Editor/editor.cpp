 // ADT binary tree operations
#include"editor.h"
#include<Windows.h>

 void colorText(int value) {

	COORD coord;

	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	FlushConsoleInputBuffer(hConsole);

	SetConsoleTextAttribute(hConsole, value + 240);

}

XiEditor::XiEditor(string text,string keywords)
{
	string keyword;
	ifstream textFile;
	ifstream nonsortedKeywords;
	textFile.open(text);
	nonsortedKeywords.open(keywords);
	

	
	//Check if the files exist
	if (!textFile){
		cout << "Text File does not exist!!";
		return;}

	if (!nonsortedKeywords) {
		cout << "Keyword file does not exist!!";
		return;}

	//Creates instance of BST and adds all the keywords into it
	
	while (!nonsortedKeywords.eof()){
		nonsortedKeywords >> keyword;
		keywordTreePtr->add(keyword);
	}
	nonsortedKeywords.close();



	//Default values
	_curLine = 1;
	_curPosition = 0;
	_previousPosition = 0;
	string garbage;
	int i = 1;

	

	//Fills Linked List with lines from text file
	while (!textFile.eof())
	{
		
		string nextLine;
		getline(textFile, nextLine);
		_lines.insert(i, nextLine);
		i++;
	}
	
	

	string userInput;
	//User input for userInputk


	printLines();
	while (userInput != "0")
	{
		//Menu Print out awaiting user input


		system("cls");
		printLines();
	

		userInput = _getch();


		if (userInput == "j") {

			moveDown();
		}

		else if (userInput == "k") {
			moveUp();
		}

		else if (userInput == "l") {
			moveRight();
		}

		else if (userInput == "h") {
			moveLeft();
		}

		else if (userInput == "u")
			undo();

		else if (userInput == "x"){
			removeChar();
		}

		else if (userInput == "0")
			return;

		else if (userInput == "d"){

			system("cls");
			printLines();
			string secondUserInput;
			secondUserInput = _getch();
			if (secondUserInput == "d")
			{
				removeLine();
			}}

		//Insert char mode
		else if (userInput == "i") {
			insertChar();
		}

		else if (userInput == "I")
			insertLine();
		
		else
		{
			cout << "ERROR - CHECK YOUR INPUT! " << endl << endl;
		}
		fixText();
	}



}      




void XiEditor::gotoXY(int column, int line){
	COORD coord;
	coord.X = column;
	coord.Y = line;
	SetConsoleCursorPosition(
		GetStdHandle(STD_OUTPUT_HANDLE),
		coord);
}
void XiEditor::printLines()
{
	//If windows system
#ifdef _WIN32

	string nextLine;
	string getWords;

	for (int i = 1; i <= _lines.getLength(); i++)
	{

		nextLine = _lines.getEntry(i);
		istringstream ss(nextLine);
		while (getline(ss,getWords,' ')) {
			if (keywordTreePtr->contains(getWords))

				colorText(1);  //blue

			else

				colorText(0);
			cout << "" << getWords << " ";
		}
		cout << endl;



	}




	gotoXY(_curPosition, _curLine - 1);


#else
	string nextLine;
	string getWords;


	//Using size for now NEEDS TO BE CHANGED
	for (int i = 1; i <= _lines.getLength(); i++)
	{
		//If at line, shows the star

		nextLine = _lines.getEntry(i);
		istringstream ss(nextLine);
		if (i == _curLine)
		{
			cout << "*";
		}
		while (getline(ss, getWords, ' ')) {
			if (keywordTreePtr->contains(getWords))

				//printf("\033[0;34m" , getWords,"\033[m");
				cout << "\033[0;34m" << getWords << "\033[m" << " ";
			else
				cout << getWords << " ";
		}


		cout << endl;
		if (i == _curLine) {
			for (int j = 0; j < _curPosition; j++) {
				cout << " ";
			}
			cout << " ^" << endl;
		}
	}



}

#endif
}

void XiEditor::removeLine()
{
	int i = _curLine;
	CommandPlus dCommand('d', _lines.getEntry(i), _curLine);
    
	//Deletes line and moves every up
	_lines.remove(i);

	//Prepares for the undo function
	undoStack.push(dCommand);



 } 

void XiEditor::removeChar()
{

	string charInLine = _lines.getEntry(_curLine);
	string charToDelete(1, charInLine[_curPosition]);

	CommandPlus XCommand('x', charToDelete, _curPosition);
	if (_curPosition >= 0)
	{
		undoStack.push(XCommand);
		//Saved for undo
		charInLine.erase(_curPosition,1);
	}
	_lines.replace(_curLine, charInLine);
}

void XiEditor::moveLeft()
{
		_curPosition--;
		CommandPlus CommandToUndo('h');
		undoStack.push(CommandToUndo);
}
void XiEditor::moveRight()
{
		_curPosition++;
		CommandPlus CommandToUndo('l');
		undoStack.push(CommandToUndo);
}
void XiEditor::moveUp()
{
	CommandPlus CommandToUndo('j', "", _curPosition);
	undoStack.push(CommandToUndo);
	_curLine--;
		
}

void XiEditor::moveDown()
{
	CommandPlus CommandToUndo('k', "", _curPosition);
	undoStack.push(CommandToUndo);
	_curLine++;
		
}


void XiEditor::fixText()
{
	int numberOfLines = _lines.getLength();

	//If it overflows above
	if (_curLine<1)
	{
		_curLine = 1;
	}

	//If it overflows below
	else if (_curLine > numberOfLines-1)
	{
		_curLine = numberOfLines;
	}



	string lineContent = _lines.getEntry(_curLine);
	int lineLength = lineContent.length();

	//If it overflows to the left
	if (_curPosition < 0)
	{
		_curPosition = 0;
	}

	//If it overflows to the right
	else if (_curPosition > lineLength)
	{
		_curPosition = lineLength;
	}


	
	 
}


void XiEditor::undo()
{
	if (!undoStack.isEmpty())
	{
		CommandPlus previousCommand = undoStack.peek();
		undoStack.pop();
		string deletedString = previousCommand.returnDeletedLine();
		string lineToUndo = _lines.getEntry(_curLine);
		int positionAfterUndo = previousCommand.returnDeletedPosition();
		switch (previousCommand.returnCommand())
		{
		case 'j':
			_curLine++;
			_curPosition = positionAfterUndo;
			break;
		case'k':
			_curLine--;
			_curPosition = positionAfterUndo;
			break;
		case 'h':
			_curPosition++;
			break;
		case 'l':
			_curPosition--;
			break;
		case 'x':
		
			lineToUndo.insert(positionAfterUndo, deletedString);
			_lines.replace(_curLine, lineToUndo);
			break;
			
		case 'd':
			_lines.insert(_curLine, deletedString);
			break;
		case 'I':
			_lines.remove(_curLine);
			break;
		case 'i':
			string newLine = _lines.getEntry(_curLine);
			newLine.erase(_curPosition - 1, 1);
			_lines.replace(_curLine, newLine);
			_curPosition--;
		}}}



void XiEditor::addToUndo(char add) {

	CommandPlus prepareUndo(add);
	undoStack.push(prepareUndo);

}

void XiEditor::insertChar() {

	string userInput;

	getline(cin, userInput);
	int userInputLength = userInput.length();
	string insertIn = _lines.getEntry(_curLine);

	insertIn.insert(_curPosition, userInput);
	_lines.replace(_curLine, insertIn);
	_curPosition += userInputLength;

	//Prepare to undo

	for (int i = 0; i < userInputLength; i++)
	{
		CommandPlus prepareUndo('i');
		undoStack.push(prepareUndo);

	}

}


void XiEditor::insertLine()
{
	string userInput;
	getline(cin, userInput);
	_lines.insert(_curLine, userInput);
	addToUndo('I');
}