
//#include <string>
//#include <fstream>
//#include"editor.h"
//#include"CommandPlus.h"

#include"editor.h"
using namespace std;


// this program doesn't do much yet
void main(int argc, char * argv[]) {
	XiEditor editor(argv[1],argv[2]);
}